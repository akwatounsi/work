package de.uni_stuttgart.iaas.benchflow.importer;

import java.nio.file.Path;
import java.util.Set;

import org.camunda.bpm.model.xml.ModelInstance;

import de.uni_stuttgart.iaas.benchflow.importer.enums.FileExtention;


/**
 * Strategy class of the strategy pattern (slightly modified) managing importing of models.
 * 
 * @author vincenzoferme
 *
 */
public interface ImporterStrategy {

	public Set<? extends ModelInstance> doImport(Set<Path> rootDirs, Set<FileExtention> fileTypes);
	
}
