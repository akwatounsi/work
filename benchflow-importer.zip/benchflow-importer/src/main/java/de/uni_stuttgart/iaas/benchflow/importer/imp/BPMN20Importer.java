package de.uni_stuttgart.iaas.benchflow.importer.imp;

import de.uni_stuttgart.iaas.benchflow.importer.GenericImporter;

public abstract class BPMN20Importer extends GenericImporter {

	private String serializationFormat;

	public void extractMetadata(){
		//TODO
	}
	
	public String getSerializationFormat() {
		return serializationFormat;
	}

	public void setSerializationFormat(String serializationFormat) {
		this.serializationFormat = serializationFormat;
	}
	
	
}
