package de.uni_stuttgart.iaas.benchflow.importer;

import java.io.File;

public abstract class GenericImporter implements ImporterStrategy {

	String name = "";
	File modelFoot = null;
	
}
