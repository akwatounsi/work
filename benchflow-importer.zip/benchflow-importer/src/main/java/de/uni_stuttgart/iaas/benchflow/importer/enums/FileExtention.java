package de.uni_stuttgart.iaas.benchflow.importer.enums;


public enum FileExtention {

	XML("xml"), BPMN("bpmn");
	 
	private String fileExtention;
 
	private FileExtention(String ext) {
		fileExtention = ext;
	}

	public String getFileExtention() {
		return fileExtention;
	}
	
	public static boolean acceptedExtention(String ext){
		
		boolean acceptedExt = false;
		if(FileExtention.BPMN.getFileExtention().equalsIgnoreCase(ext) || FileExtention.XML.getFileExtention().equalsIgnoreCase(ext))
			acceptedExt = true;
		
		return acceptedExt;
	}
	
}
