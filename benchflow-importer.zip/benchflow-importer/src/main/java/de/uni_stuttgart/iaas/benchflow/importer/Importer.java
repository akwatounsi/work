package de.uni_stuttgart.iaas.benchflow.importer;

import java.nio.file.Path;
import java.util.Set;

import org.camunda.bpm.model.xml.ModelInstance;

import de.uni_stuttgart.iaas.benchflow.importer.enums.FileExtention;

public class Importer {
	
	private ImporterStrategy strategy;
	 
    public Importer(ImporterStrategy strategy) {
        this.strategy = strategy;
    }
    public Set<? extends ModelInstance> importModels(Set<Path> rootDirs, Set<FileExtention> fileTypes) {
        return this.strategy.doImport(rootDirs, fileTypes);
    }
	
}
