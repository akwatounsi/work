package de.uni_stuttgart.iaas.benchflow.importer.imp;

import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.FileVisitor;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.LinkedHashSet;
import java.util.Set;

import org.apache.commons.io.FilenameUtils;
import org.camunda.bpm.model.bpmn.Bpmn;
import org.camunda.bpm.model.bpmn.BpmnModelInstance;

import de.uni_stuttgart.iaas.benchflow.importer.enums.FileExtention;


public class XmlBPMN20Importer extends BPMN20Importer {
	
	static Set<BpmnModelInstance> importedModels = new LinkedHashSet<BpmnModelInstance>();
	
	public Set<BpmnModelInstance> doImport(Set<Path> rootDirs, Set<FileExtention> fileTypes) {
		
		for(Path root : rootDirs){
			
//			System.out.println(FileExtention.filterFromExtentionSet(fileTypes));
			
			FileVisitor<Path> fileProcessor = new ProcessFile();
		    try {
				Files.walkFileTree(root, fileProcessor);
			} catch (IOException e) {
				// TODO-EXCEPTION_HANDLING
				e.printStackTrace();
			}
			
		}
		
		return importedModels;
	}
	
	private static final class ProcessFile extends SimpleFileVisitor<Path> {
		@Override public FileVisitResult visitFile(Path aFile, BasicFileAttributes aAttrs) throws IOException {

			if(aFile.toFile().isFile()){
				
				String fileExt = FilenameUtils.getExtension(aFile.toFile().getName());

				if(FileExtention.acceptedExtention(fileExt)){
//					System.out.println("File: " + aFile);
					BpmnModelInstance model = Bpmn.readModelFromFile(aFile.toFile());
//					System.out.println(model.getDocument());
//					System.out.println(model.isCorrect());
					if(model!=null && model.isCorrect() && model.getDocument()!=null){
						
						importedModels.add(model);
//						System.out.println("Imported");
					} else {
						System.out.println("Skipped for errors: " + aFile); 
					}
					
				}
	    	}
			
			return FileVisitResult.CONTINUE;
		}

		@Override  public FileVisitResult preVisitDirectory(Path aDir, BasicFileAttributes aAttrs) throws IOException {
//			System.out.println("Processing directory:" + aDir);
			return FileVisitResult.CONTINUE;
		}
	}
	
}
