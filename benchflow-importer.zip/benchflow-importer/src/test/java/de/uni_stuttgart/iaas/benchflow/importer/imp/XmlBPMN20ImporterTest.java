/* Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package de.uni_stuttgart.iaas.benchflow.importer.imp;

import java.net.URISyntaxException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Set;

import org.camunda.bpm.model.bpmn.Bpmn;
import org.camunda.bpm.model.bpmn.BpmnModelInstance;
import org.camunda.bpm.model.bpmn.instance.DataInput;
import org.camunda.bpm.model.bpmn.instance.DataOutput;
import org.camunda.bpm.model.bpmn.instance.ExclusiveGateway;
import org.camunda.bpm.model.bpmn.instance.IntermediateCatchEvent;
import org.camunda.bpm.model.bpmn.instance.ParallelGateway;
import org.camunda.bpm.model.bpmn.instance.ResourceRole;
import org.camunda.bpm.model.bpmn.instance.SubProcess;
import org.camunda.bpm.model.bpmn.instance.Task;
import org.camunda.bpm.model.xml.ModelInstance;
import org.camunda.bpm.model.xml.ModelValidationException;
import org.camunda.bpm.model.xml.instance.ModelElementInstance;
import org.camunda.bpm.model.xml.type.ModelElementType;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import de.uni_stuttgart.iaas.benchflow.importer.Importer;
import de.uni_stuttgart.iaas.benchflow.importer.enums.FileExtention;

/**
 * @author vincenzoferme
 */
public class XmlBPMN20ImporterTest {

	private static Set<? extends ModelInstance> importedInstances;
	
	
	public static void main(String args[]) throws URISyntaxException{
		
		parseModel();
		new XmlBPMN20ImporterTest().testImport();
//		validateModel();
		
	}

	@BeforeClass
	public static void parseModel() {
		importedInstances = new LinkedHashSet<BpmnModelInstance>();
	}

	@Test
	public void testImport() throws URISyntaxException {
		
		Importer imp = new Importer(new XmlBPMN20Importer());		
		Set<Path> roots = new LinkedHashSet<Path>();
		Set<FileExtention> exts = new LinkedHashSet<FileExtention>();
		
		roots.add(Paths.get(XmlBPMN20ImporterTest.class.getResource("/models/Small Examples/IBM").toURI()));
		
		exts.add(FileExtention.BPMN);
		
		importedInstances = imp.importModels(roots, exts);
		
		for(ModelInstance instance : importedInstances){

			//TODO: cause I validate model during the parsing, add a valid flag and skip not valid models
			
			System.out.println(((BpmnModelInstance) instance).getPath());
			
			// find all elements of the type task
			ModelElementType taskType = instance.getModel().getType(Task.class);
			Collection<ModelElementInstance> elementInstances = instance.getModelElementsByType(taskType);
			System.out.println("Number of Tasks: " + elementInstances.size());
			
			ModelElementType exclusiveGatewayType = instance.getModel().getType(ExclusiveGateway.class);
			Collection<ModelElementInstance> elementInstances1 = instance.getModelElementsByType(exclusiveGatewayType);
			System.out.println("Number of Exclusive Gateway: " + elementInstances1.size());
			
			ModelElementType parallelGatewayType = instance.getModel().getType(ParallelGateway.class);
			Collection<ModelElementInstance> elementInstances11 = instance.getModelElementsByType(parallelGatewayType);
			System.out.println("Number of Parallel Gateway: " + elementInstances11.size());
			
			ModelElementType dataInputType = instance.getModel().getType(DataInput.class);
			Collection<ModelElementInstance> elementInstances111 = instance.getModelElementsByType(dataInputType);
			System.out.println("Number of Data Input: " + elementInstances111.size());
			
			ModelElementType dataOutputType = instance.getModel().getType(DataOutput.class);
			Collection<ModelElementInstance> elementInstances1111 = instance.getModelElementsByType(dataOutputType);
			System.out.println("Number of Data Output: " + elementInstances1111.size());
			
			ModelElementType subProcessType = instance.getModel().getType(SubProcess.class);
			Collection<ModelElementInstance> elementInstances11111 = instance.getModelElementsByType(subProcessType);
			System.out.println("Number of Sub Processes: " + elementInstances11111.size());
			
			ModelElementType IntermediateCatchEventType = instance.getModel().getType(IntermediateCatchEvent.class);
			Collection<ModelElementInstance> elementInstances111111 = instance.getModelElementsByType(IntermediateCatchEventType);
			System.out.println("Number of IntermediateCatchEventType: " + elementInstances111111.size());
			
			ModelElementType ResourceRoleType = instance.getModel().getType(ResourceRole.class);
			Collection<ModelElementInstance> elementInstances1111111 = instance.getModelElementsByType(ResourceRoleType);
			System.out.println("Number of ResourceRoleType: " + elementInstances1111111.size());			
			
			if(elementInstances1111111.size()>0)
				System.out.println(">>>Number of ResourceRoleType: " + elementInstances1111111.size());
			
			/*
			for(ModelElementInstance exGat : elementInstances1){
				ExclusiveGateway gat = (ExclusiveGateway) exGat;
				Query<FlowNode> prev = gat.getPreviousNodes();
				
				Query<Task> tasks = prev.filterByType(Task.class);
				
				for(Task t : tasks.list()){
					System.out.println("Prev Task Name: " + t.getName());
				}
			}
			*/
				
			
		}
		
//		assertThat(collaboration.getConversationNodes()).hasSize(1);
	}

	@AfterClass
	public static void validateModel() {
		for(ModelInstance instance : importedInstances){
			try {
				Bpmn.validateModel((BpmnModelInstance) instance);
			} catch (ModelValidationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
