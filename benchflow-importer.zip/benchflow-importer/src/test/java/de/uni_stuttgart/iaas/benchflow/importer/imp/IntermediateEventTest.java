/* Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package de.uni_stuttgart.iaas.benchflow.importer.imp;

import java.net.URISyntaxException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Set;

import org.camunda.bpm.model.bpmn.BpmnModelInstance;
import org.camunda.bpm.model.bpmn.instance.Event;
import org.camunda.bpm.model.bpmn.instance.IntermediateCatchEvent;
import org.camunda.bpm.model.bpmn.instance.IntermediateThrowEvent;
import org.camunda.bpm.model.xml.ModelInstance;
import org.camunda.bpm.model.xml.instance.ModelElementInstance;
import org.camunda.bpm.model.xml.type.ModelElementType;
import org.junit.BeforeClass;
import org.junit.Test;

import de.uni_stuttgart.iaas.benchflow.importer.Importer;
import de.uni_stuttgart.iaas.benchflow.importer.enums.FileExtention;

/**
 * @author vincenzoferme
 */
public class IntermediateEventTest {

	private static Set<? extends ModelInstance> importedInstances;
	
	
	public static void main(String args[]) throws URISyntaxException{
		
		parseModel();
		new IntermediateEventTest().testImport();
		
	}

	@BeforeClass
	public static void parseModel() {
		importedInstances = new LinkedHashSet<BpmnModelInstance>();
	}

	@Test
	public void testImport() throws URISyntaxException {
		
		Importer imp = new Importer(new XmlBPMN20Importer());		
		Set<Path> roots = new LinkedHashSet<Path>();
		Set<FileExtention> exts = new LinkedHashSet<FileExtention>();
		
		roots.add(Paths.get(IntermediateEventTest.class.getResource("/models/Custom/IntermediateEventTest.bpmn").toURI()));
		
		exts.add(FileExtention.BPMN);
		
		importedInstances = imp.importModels(roots, exts);
		
		for(ModelInstance instance : importedInstances){
			
			System.out.println(((BpmnModelInstance) instance).getPath());
			
			ModelElementType type1 = instance.getModel().getType(Event.class);
			Collection<ModelElementInstance> elementInstances1 = instance.getModelElementsByType(type1);
			System.out.println("Number of Event: " + elementInstances1.size());
			
			ModelElementType type = instance.getModel().getType(IntermediateCatchEvent.class);
			Collection<ModelElementInstance> elementInstances = instance.getModelElementsByType(type);
			System.out.println("Number of IntermediateCatchEvent: " + elementInstances.size());
			
			ModelElementType type2 = instance.getModel().getType(IntermediateThrowEvent.class);
			Collection<ModelElementInstance> elementInstances2 = instance.getModelElementsByType(type2);
			System.out.println("Number of IntermediateThrowEvent: " + elementInstances2.size());
		}

	}

}
