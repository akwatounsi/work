/* Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package de.uni_stuttgart.iaas.benchflow.importer.imp;

import java.net.URISyntaxException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Set;

import org.camunda.bpm.model.bpmn.BpmnModelInstance;
import org.camunda.bpm.model.bpmn.instance.Activity;
import org.camunda.bpm.model.bpmn.instance.MultiInstanceLoopCharacteristics;
import org.camunda.bpm.model.bpmn.instance.StandardLoopCharacteristics;
import org.camunda.bpm.model.xml.ModelInstance;
import org.camunda.bpm.model.xml.instance.ModelElementInstance;
import org.camunda.bpm.model.xml.type.ModelElementType;
import org.junit.BeforeClass;
import org.junit.Test;

import de.uni_stuttgart.iaas.benchflow.importer.Importer;
import de.uni_stuttgart.iaas.benchflow.importer.enums.FileExtention;

/**
 * @author vincenzoferme
 */
public class LoopCharacteristicsTest {

	private static Set<? extends ModelInstance> importedInstances;


	public static void main(String args[]) throws URISyntaxException{

		parseModel();
		new LoopCharacteristicsTest().testImport();

	}

	@BeforeClass
	public static void parseModel() {
		importedInstances = new LinkedHashSet<BpmnModelInstance>();
	}

	@Test
	public void testImport() throws URISyntaxException {

		Importer imp = new Importer(new XmlBPMN20Importer());		
		Set<Path> roots = new LinkedHashSet<Path>();
		Set<FileExtention> exts = new LinkedHashSet<FileExtention>();

		roots.add(Paths.get(LoopCharacteristicsTest.class.getResource("/models/Custom/LoopCharacteristicsTest.bpmn").toURI()));

		exts.add(FileExtention.BPMN);

		importedInstances = imp.importModels(roots, exts);

		for(ModelInstance instance : importedInstances){

			System.out.println(((BpmnModelInstance) instance).getPath());

			ModelElementType activityType = instance.getModel().getType(Activity.class);
			Collection<ModelElementInstance> activities = instance.getModelElementsByType(activityType);

			for(ModelElementInstance ac : activities){

				Activity act = (Activity) ac;
				
				if(act.getLoopCharacteristics() instanceof StandardLoopCharacteristics){
					
					StandardLoopCharacteristics loop = (StandardLoopCharacteristics) act.getLoopCharacteristics();
					
					System.out.println(act.getId() + ": " + loop.getClass().getSimpleName());
					
				} else if(act.getLoopCharacteristics() instanceof MultiInstanceLoopCharacteristics){
					
					MultiInstanceLoopCharacteristics loop = (MultiInstanceLoopCharacteristics) act.getLoopCharacteristics();
					
					if(loop.isSequential()){
						System.out.println(act.getId() + ": " + loop.getClass().getSimpleName() + " - " + loop.isSequential());
					} else {
						System.out.println(act.getId() + ": " + loop.getClass().getSimpleName() + " - " + loop.isSequential());
					}
					
				}

			}

		}

	}
}
