/* Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package de.uni_stuttgart.iaas.benchflow.importer.imp;

import java.net.URISyntaxException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Set;

import org.camunda.bpm.model.bpmn.BpmnModelInstance;
import org.camunda.bpm.model.bpmn.impl.instance.SubProcessImpl;
import org.camunda.bpm.model.bpmn.instance.Activity;
import org.camunda.bpm.model.bpmn.instance.AdHocSubProcess;
import org.camunda.bpm.model.bpmn.instance.SubProcess;
import org.camunda.bpm.model.bpmn.instance.TransactionSubProcess;
import org.camunda.bpm.model.xml.ModelInstance;
import org.camunda.bpm.model.xml.instance.ModelElementInstance;
import org.camunda.bpm.model.xml.type.ModelElementType;
import org.junit.BeforeClass;
import org.junit.Test;

import de.uni_stuttgart.iaas.benchflow.importer.Importer;
import de.uni_stuttgart.iaas.benchflow.importer.enums.FileExtention;

/**
 * @author vincenzoferme
 */
public class SubProcessCountAsActivityTest {

	private static Set<? extends ModelInstance> importedInstances;
	
	
	public static void main(String args[]) throws URISyntaxException{
		
		parseModel();
		new SubProcessCountAsActivityTest().testImport();
		
	}

	@BeforeClass
	public static void parseModel() {
		importedInstances = new LinkedHashSet<BpmnModelInstance>();
	}

	@Test
	public void testImport() throws URISyntaxException {
		
		Importer imp = new Importer(new XmlBPMN20Importer());		
		Set<Path> roots = new LinkedHashSet<Path>();
		Set<FileExtention> exts = new LinkedHashSet<FileExtention>();
		
		roots.add(Paths.get(SubProcessCountAsActivityTest.class.getResource("/models/Custom/SubProcessCountAsActivityTest.bpmn").toURI()));
		
		exts.add(FileExtention.BPMN);
		
		importedInstances = imp.importModels(roots, exts);
		
		for(ModelInstance instance : importedInstances){
			
			System.out.println(((BpmnModelInstance) instance).getPath());
			
			// find all elements of the type task
			ModelElementType activityType = instance.getModel().getType(Activity.class);
			Collection<ModelElementInstance> elementInstances = instance.getModelElementsByType(activityType);
			System.out.println("Number of Activity: " + elementInstances.size());
			
			// count all different types of subprocesses
			ModelElementType subProcessType = instance.getModel().getType(SubProcess.class);
			Collection<ModelElementInstance> elementInstances11111 = instance.getModelElementsByType(subProcessType);
			System.out.println("Number of Sub Processes: " + elementInstances11111.size());
			
			// count only event based subprocesses
			double eventBased = 0;
			
			for(ModelElementInstance eb : elementInstances11111){
				SubProcess sub = (SubProcess) eb;
				
				if(sub.triggeredByEvent())
					eventBased++;
			}
			
			System.out.println("Number of Event Based Sub Processes: " + eventBased);
			
			// count only subprocess mapped to subprocess BPMN 2.0 tag that are not triggered by an event
			double subpr = 0;
			
			for(ModelElementInstance eb : elementInstances11111){
				SubProcess sub = (SubProcess) eb;

				if(sub.getClass().equals(SubProcessImpl.class) && !sub.triggeredByEvent())
					subpr++;
			}
			
			System.out.println("Number of BPMN 2.0 Tag Processes: " + subpr);
			
			// count only ad hoc subprocess
			ModelElementType adHocSubProcessType = instance.getModel().getType(AdHocSubProcess.class);
			Collection<ModelElementInstance> elementInstances111111 = instance.getModelElementsByType(adHocSubProcessType);
			System.out.println("Number of Ad Hoc Sub Processes: " + elementInstances111111.size());
			
			// count only transaction subprocess
			@SuppressWarnings("unused")
			ModelElementType TransactionSubProcessType = instance.getModel().getType(TransactionSubProcess.class);
			Collection<ModelElementInstance> elementInstances1111111 = instance.getModelElementsByType(adHocSubProcessType);
			System.out.println("Number of Transaction Sub Processes: " + elementInstances1111111.size());
			
		}

	}

}
